function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(40, 20, 30);
  
  rect(70, 50, 130, 200);
  let c=color(255, 204, 40);
  fill(c);
  noStroke();
  
  rect(75, 190, 120, 50);
  let d=color(2, 204, 40);
  fill(d);
  noStroke();
  
  circle(90, 80, 20, 20);
  circle(180, 80, 20, 20);
  ellipse(130, 150, 100, 50);
  let e=color(230, 30, 30);
  fill(e);
  noStroke();
  
}