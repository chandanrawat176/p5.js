function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(20, 20 ,20);
  
  ellipseMode(CENTER);
  let c = color(255, 204, 0);
  fill(c);
  noStroke();
  circle(150, 200, 200);
  
  noFill();
  fill(0,0,0);
  circle(120,190, 50, 50);
  circle(190, 190, 50, 50);
  
  noFill();
  fill(125, 125, 125);
  arc(150, 250, 80, 80, 0, PI + QUARTER_PI, PI);
  
}